function toggleMenu() {
  var menu = document.getElementById("menuOpciones");
  if (menu.style.display === "block") {
    menu.style.display = "none";
  } else {
    menu.style.display = "block";
  }
}
