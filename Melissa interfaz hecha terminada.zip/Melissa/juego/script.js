//NUEVO
let direcionItems = ["/img/trevol.jpg","/img/naranja.jpg","/img/campana.jpg", "/img/siete.jpg", "/img/manzana.jpg", "/img/cereza.jpg","/img/trevol.jpg","/img/uva.jpg"];
// Numero de rieles
const rieles = ["riel1", "riel2", "riel3", "riel4", "riel5"];
// numero de items por riel
const itemRiel = 3;
// los nombres de los items
const frutas = ["bar", "siete", "bonus", "carta", "cereza", "corona", "manzana", "wild"];
// la probaabiliad de los items 
const probabilidades = [0.25, 0.25, 0.1, 0.1, 0.1, 0.1, 0.05, 0.05];
// frutas caidas en e
let frutasObtenidas = [];
// La cantidad de items necesarios para los giros(Calcular)
let itemsRiel = [12,17,22,27,50];
// Tiempo de giro para cada riel 
let duracionGiro = [2400, 3500, 3500, 4500, 5500];
// Desplazamiento en  px que tendra cada riel
let desplazamientoRiel = [-2390, -3390, -4390, -5390, -6390];

    //Genera una cantidad n de items aletorios 
    function generarItems(cantidadItems){
        let frutasSeleccionada = [];
       

        for(let j = 0; j < cantidadItems; j++){
            let valorRandom = Math.random();
            let acumuladorProbabilidades = 0;
            let frutaSeleccionada = '';
            console.log("VALOR RAMDON  " + j  + ": " +valorRandom);
            for(let i = 0; i < frutas.length; i++){
                acumuladorProbabilidades += probabilidades[i];
                if(acumuladorProbabilidades >= valorRandom  - 0.0001){
                    frutaSeleccionada = frutas[i];
                    console.log("Ingreso al condicional, valor de fruta: " + frutas[i] + " y fruta seleccionada: " + frutaSeleccionada);
                    break;
                }    
            }
            console.log("ACumulador: "+ acumuladorProbabilidades);
            frutasSeleccionada[j] = frutaSeleccionada;
        }
        console.log(frutasSeleccionada);
        return  frutasSeleccionada;
    }
    
    //Genera los rieles con las imagenes
    function generarRieles(rielId){
        //console.log("ingreso a generarRieles");
        let contadorid = 0;
        let cantidadItemsGenerar = 0;

        for(let i = 0; i < rieles.length; i++){
            if(rieles[i] == rielId){
                cantidadItemsGenerar = itemsRiel[i];
                //console.log("cantidadITemGenerar = " + cantidadItemsGenerar + " y  array: " + itemsRiel[i]);
            }
        }
        let itemSeleccionado = generarItems(cantidadItemsGenerar);
        let rielDiv = document.getElementById(rielId);

        for(let i = 0; i < itemSeleccionado.length; i++){
            let img = document.createElement('img');
            img.src = "1x/" + itemSeleccionado[i] + ".png";
            img.id = contadorid++;
            img.alt = itemSeleccionado[i];
            rielDiv.appendChild(img);
        }

    }
    function eliminarIdsImagenes(rielId) {
        const rielDiv = document.getElementById(rielId);
        const imagenes = rielDiv.querySelectorAll("img");
        imagenes.forEach(imagen => {
            imagen.removeAttribute("id");
        });
    }

    function animacion(rielId){
        generarRieles(rielId);
        const riel = document.getElementById(rielId);
        const imagenes = riel.getElementsByTagName('img');    
        const intervalo =  1;
        let duracionTotal = 0; 
        let desplazamiento = 0;
        let desplazamientoTotal = 0;
        let multiplicador = 0;

        for(let i = 0; i < rieles.length; i++){
            if(rieles[i] == rielId){
                duracionTotal = duracionGiro[i];
                desplazamientoTotal = desplazamientoRiel[i];
                multiplicador = i;
            }
        }
        const animacion = setInterval(() => {
            for (let i = 0; i < imagenes.length; i++) {
                imagenes[i].style.visibility = 'visible'; 
                imagenes[i].style.transform = `translateY(${desplazamiento}px)`;
            }
            if (desplazamiento >= desplazamientoTotal) {
                desplazamiento -= 10;  
                //console.log("DESPLAZMIENTO TOTAL: " + desplazamientoTotal);
            }
            console.log("Valor de desplazamiento: " + desplazamiento);
        }, intervalo);

        setTimeout(() => {
                clearInterval(animacion);
                setTimeout( () => {
                    const rielDiv = document.getElementById(rielId);
                    const imagenes = rielDiv.querySelectorAll("img");
                    imagenes.forEach(imagen => {
                        const id = parseInt(imagen.id);
                        if (id !== (9 + (multiplicador *  5) ) && id !== (10 + (multiplicador *  5)) && id !== (11 + (multiplicador *  5))) {
                            rielDiv.removeChild(imagen);
                        }else{
                            imagen.style.transform = "translateY(0px)";                        
                        }
                });
                eliminarIdsImagenes(rielId);
                }, 10);
        }, duracionTotal);
    }
    
    function iniciarAnimacion() {
    animacion("riel1");
    animacion('riel2');
    animacion("riel3");
    animacion("riel4");
    animacion("riel5");
        console.log("RESULTADOS: " + frutas);
    }
